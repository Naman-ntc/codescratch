import sys,os,io
input = sys.stdin.readline # for strings
# input = io.BytesIO(os.read(0, os.fstat(0).st_size)).readline # for non-strings

PI = 3.141592653589793238460
INF =  float('inf')
MOD  = 1000000007
# MOD = 998244353


def bin32(num):
    return '{0:032b}'.format(num)

def add(x,y):
    return (x+y)%MOD

def sub(x,y):
    return (x-y+MOD)%MOD

def mul(x,y):
    return (x*y)%MOD

def gcd(x,y):
    if y == 0:
        return x
    return gcd(y,x%y)

def lcm(x,y):
    return (x*y)//gcd(x,y)

def power(x,y):
    res = 1
    x%=MOD
    while y!=0:
        if y&1 :
            res = mul(res,x)
        y>>=1
        x = mul(x,x)
        
    return res
        
def mod_inv(n):
    return power(n,MOD-2)

def prob(p,q):
    return mul(p,power(q,MOD-2))    
  
def ii():
    return int(input())

def li():
    return [int(i) for i in input().split()]

def ls():
    return [i for i in input().split()]

for t in range(ii()):
    t+=1
    n,k = li()
    a = li()

    pos = []
    neg = []
    for i in a:
        if i > 0:
            pos.append(i)
        elif i < 0:
            neg.append(-i)
    pos.sort()
    neg.sort()
    ans = 0
    if len(pos) == 0 and len(neg) == 0:
        print(0)
        continue

    x = pos[:max(0 , len(pos)-k)]
    x.reverse()
    i = 0
    # print(x)
    while i < len(x):
        ans+= 2*x[i]
        i+=k
    
    x = neg[:max(0 , len(neg)-k)]
    x.reverse()
    i = 0
    # print(x)
    while i < len(x):
        ans+= 2*x[i]
        i+=k
    
    if len(pos) == 0:
        ans+= neg[-1]
    if len(neg) == 0:
        ans+= pos[-1]
    if len(neg) > 0 and len(pos) > 0:
        ans+= 2*min(pos[-1],neg[-1])
        ans+= max(neg[-1] , pos[-1])
    print(ans)