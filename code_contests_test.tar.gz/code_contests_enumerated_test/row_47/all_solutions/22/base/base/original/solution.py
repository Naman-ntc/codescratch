from sys import stdin
for _ in range(int(stdin.readline())):
    n,k=map(int,stdin.readline().split())
    arr=list(map(int,stdin.readline().split()))
    R=[]
    L=[]
    for i in arr:
        if i>0:
            R.append(i)
        else:
            L.append(abs(i)) 
    R.sort(reverse=True)
    L.sort(reverse=True)
    #print(L,R)
    ans=0 
    if R!=[]:
      ans=R[0]
      d=R[0]
      v=k
      for i in R:
        #print(ans)
        if v==0:
            ans+=(2*i)
            v=k 
        v-=1
    if len(L)>0:
        ans+=L[0] 
        v=k
        if len(R)>0:
          if L[0]<R[0]:
            ans+=L[0]
          else:
            ans+=R[0]
        for i in L:
            #print(ans)
            if v==0:
                ans+=(2*i)
                v=k 
            v-=1
    print(ans)