for t in range(int(input())):
    num_test_cases, max_bags = tuple(map(int, input().split()))
    depot_positions = sorted(list(map(int, input().split())))
    negative_positions = list(filter(lambda position: position < 0, depot_positions))
    positive_positions = list(filter(lambda position: position > 0, depot_positions))
    
    cost = sum([2 * (-negative_positions[i]) for i in range(0, len(negative_positions), max_bags)]) + sum([2 * positive_positions[i] for i in range(len(positive_positions) - 1, -1, -max_bags)])
    
    if len(negative_positions) and len(positive_positions):
        cost -= max((-negative_positions[0]), positive_positions[-1])
    elif len(negative_positions):
        cost -= (-negative_positions[0])
    elif len(positive_positions):
        cost -= positive_positions[-1]
    
    print(cost)