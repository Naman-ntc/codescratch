for t in range(int(input())):
    n, k = tuple(map(int, input().split()));x = sorted(list(map(int, input().split())));negative = list(filter(lambda k: k < 0, x));positive = list(filter(lambda k: k > 0, x))
    cost = sum([2 * (-negative[i]) for i in range(0, len(negative), k)]) + sum([2 * positive[i] for i in range(len(positive) - 1, -1, -k)])
    if len(negative) and len(positive):cost -= max((-negative[0]), positive[-1])
    elif len(negative):cost -= (-negative[0])
    elif len(positive):cost -= positive[-1]
    print(cost)
