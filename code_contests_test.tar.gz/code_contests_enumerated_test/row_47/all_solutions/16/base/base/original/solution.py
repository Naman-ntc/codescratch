from sys import stdin, stdout
rd = lambda: list(map(int, stdin.readline().split()))
rds = lambda: stdin.readline().rstrip()
ii = lambda: int(stdin.readline())
INF = 1 << 62
mod = 10**9 + 7


def _f(ar, k):
    
    if not ar:
        return 0, 0

    if len(ar) <= k:
        # full array
        return 0, ar[-1]

    first = 0
    lim = len(ar) - k
    
    i = lim-1
    while i >= 0:
        first += 2 * ar[i]
        i -= k

    last = ar[-1]

    return first, last

for _ in range(ii()):
    n, k = rd()
    xs = rd()
    
    rs = [abs(x) for x in xs if x > 0]
    ls = [abs(x) for x in xs if x < 0]

    rs.sort()
    ls.sort()
    
    rf, rl = _f(rs, k)
    lf, ll = _f(ls, k)
    
    #print('rf', rf, 'rl', rl)
    #print('lf', lf, 'll', ll)

    # right return lefr
    res1 = rf + 2 * rl + lf + ll
    res2 = lf + 2 * ll + rf + rl

    print(min(res1, res2))
        

#stdout.write(' '.join(map(str, ar)))
#stdout.write(f'{res}')

