t = int(input())

for _ in range(t):
    n,k = list(map(int, input().split()))
    x = [int(h) for h in input().split()]
    x1 = []
    x2 = []
    for y in x:
        if y<0:
            x1.append(-y)
        else:
            x2.append(y)
    sum = 0
    x1.sort()
    x2.sort()
    y1 = []
    y2 = []
    while(len(x1)>k):
        y1.append(x1[len(x1)-1])
        x1 = x1[:len(x1)-k]
    if x1!=[]:
        y1.append(x1[len(x1)-1])
    while(len(x2)>k):
        y2.append(x2[len(x2)-1])
        x2 = x2[:len(x2)-k]
    if x2!=[]:
        y2.append(x2[len(x2)-1])
    y = 0
    if y1!= []:
        y = max(y,y1[0])
    if y2!= []:
        y = max(y,y2[0])
    sum-=y
    for x in y1:
        sum+=2*x
    for x in y2:
        sum+=2*x
    print(sum)