import sys
import math
import collections
import heapq

dy = [1, 0, -1, 0]
dx = [0, 1, 0, -1]

r = lambda: sys.stdin.readline().rstrip()
MIS = lambda: map(int, r().split())


for _ in range(int(r())):
    N, K = MIS()
    L = list(MIS())
    P = []
    M = []
    for i in L:
        if i > 0:
            P.append(i)
        else:
            M.append(-i)
    P.sort(reverse=1)
    M.sort(reverse=1)
    ans = 0
    a = 0
    for i in range(0, len(P), K):
        ans += max(P[i:i+K])
        a = max(a, max(P[i:i+K]))

    for i in range(0, len(M), K):
        ans += max(M[i:i+K])
        a = max(a, max(M[i:i+K]))

    print(ans*2-a)

"""
1 
9 5
-3 -4 -5 -6 0 0 1 2 3 4 7
"""