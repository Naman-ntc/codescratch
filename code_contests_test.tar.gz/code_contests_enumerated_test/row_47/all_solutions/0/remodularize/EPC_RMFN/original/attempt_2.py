def calculate_distance(num_depots, max_bags, depot_positions):
    positive_depots = get_positive_depots(depot_positions)
    negative_depots = get_negative_depots(depot_positions)

    total_distance = 0

    if positive_depots:
        positive_depots.sort()
        total_distance += calculate_positive_distance(positive_depots, max_bags)

    if negative_depots:
        negative_depots.sort(reverse=True)
        total_distance -= calculate_negative_distance(negative_depots, max_bags)

    total_distance = adjust_total_distance(total_distance, positive_depots, negative_depots)

    return total_distance


def get_positive_depots(depot_positions):
    return [position for position in depot_positions if position > 0]


def get_negative_depots(depot_positions):
    return [position for position in depot_positions if position <= 0]


def calculate_positive_distance(positive_depots, max_bags):
    total_distance = 0
    for i in range(len(positive_depots) - 1, -1, -max_bags):
        total_distance += positive_depots[i] * 2
    return total_distance


def calculate_negative_distance(negative_depots, max_bags):
    total_distance = 0
    for i in range(len(negative_depots) - 1, -1, -max_bags):
        total_distance += negative_depots[i] * 2
    return total_distance


def adjust_total_distance(total_distance, positive_depots, negative_depots):
    if not positive_depots:
        total_distance += negative_depots[-1]
    elif not negative_depots:
        total_distance -= positive_depots[-1]
    else:
        total_distance -= max(-negative_depots[-1], positive_depots[-1])
    return total_distance


def main():
    t = int(input())

    for _ in range(t):
        num_depots, max_bags = map(int, input().split())
        depot_positions = list(map(int, input().split()))

        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)


if __name__ == '__main__':
    main()