def calculate_distance(num_depots, max_bags, depot_positions):
    positive_depots = []
    negative_depots = []
    
    for position in depot_positions:
        if position > 0:
            positive_depots.append(position)
        else:
            negative_depots.append(position)

    total_distance = 0
    
    if positive_depots:
        positive_depots.sort()
        for i in range(len(positive_depots) - 1, -1, -max_bags):
            total_distance += positive_depots[i] * 2
    
    if negative_depots:
        negative_depots.sort()
        negative_depots = negative_depots[::-1]
        for i in range(len(negative_depots) - 1, -1, -max_bags):
            total_distance -= negative_depots[i] * 2
    
    if positive_depots == []:
        total_distance += negative_depots[-1]
    elif negative_depots == []:
        total_distance -= positive_depots[-1]
    else:
        total_distance -= max(-negative_depots[-1], positive_depots[-1])
    
    return total_distance


def main():
    t = int(input())
    
    for _ in range(t):
        num_depots, max_bags = map(int, input().split())
        depot_positions = list(map(int, input().split()))
        
        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)


if __name__ == '__main__':
    main()