def calculate_distance(test_cases, inputs):
    distances = []
    for i in range(test_cases):
        num_depots, max_bags = inputs[i][0]
        depot_positions = inputs[i][1]
        sorted_positions = []
        total_distance = 1

        for i in range(num_depots):
            if depot_positions[i] != 0:
                sorted_positions.append(depot_positions[i])
                total_distance += 1

        sorted_positions.append(0)
        sorted_positions.sort()
        origin_index = sorted_positions.index(0)
        remaining_depots = total_distance - origin_index - 1
        bags_per_trip = remaining_depots // max_bags
        remaining_bags = remaining_depots % max_bags
        current_position = sorted_positions[origin_index + remaining_bags]

        for i in range(bags_per_trip):
            current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]

        trips_to_origin = origin_index // max_bags
        remaining_depots_origin = origin_index % max_bags
        current_position += abs(sorted_positions[origin_index - remaining_depots_origin])

        for i in range(trips_to_origin):
            current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])

        current_position *= 2

        distances.append(current_position - max(-sorted_positions[0], abs(sorted_positions[total_distance - 1])))

    return distances


def main():
    test_cases = int(input())
    inputs = []
    for _ in range(test_cases):
        num_depots, max_bags = map(int, input().split())
        depot_positions = [int(i) for i in input().split()]
        inputs.append((num_depots, max_bags, depot_positions))

    distances = calculate_distance(test_cases, inputs)

    for distance in distances:
        print(distance)


if __name__ == '__main__':
    main()