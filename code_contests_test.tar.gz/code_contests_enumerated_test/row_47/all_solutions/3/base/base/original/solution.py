kl = int(input())
for kkl in range(kl):
  n, k = map(int, input().split())
  a= [int(i) for i in input().split()]
  b=[]
  dl=1
  for i in range(n):
    if a[i]!=0:
      b.append(a[i])
      dl+=1
  b.append(0)
  b.sort()
  i0 = b.index(0)
  kp= dl-i0-1
  kh=kp//k
  rs=kp%k
  rz=b[i0+rs]
  for i in range(kh):
    rz+=b[i0+rs+k*(i+1)]
  kh=i0//k
  rs=i0%k
  rz+=abs(b[i0-rs])
  for i in range(kh):
    rz+=abs(b[i0 -(rs+k*(i+1))])
  
  rz*=2
  
  print(rz - max(-b[0], abs(b[dl-1])))

    