def calculate_distance(num_depots, max_bags, depot_positions):
    sorted_positions = sort_positions(depot_positions)
    origin_index = get_origin_index(sorted_positions)
    remaining_depots = get_remaining_depots(origin_index, num_depots)
    bags_per_trip, remaining_bags = get_bags_per_trip(remaining_depots, max_bags)
    current_position = get_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags)
    trips_to_origin, remaining_depots_origin = get_trips_to_origin(origin_index, max_bags)
    current_position += get_distance_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags)
    current_position *= 2
    return current_position - get_adjustment(sorted_positions)

def sort_positions(depot_positions):
    sorted_positions = []
    for i in range(len(depot_positions)):
        if depot_positions[i] != 0:
            sorted_positions.append(depot_positions[i])
    sorted_positions.append(0)
    sorted_positions.sort()
    return sorted_positions

def get_origin_index(sorted_positions):
    return sorted_positions.index(0)

def get_remaining_depots(origin_index, num_depots):
    return num_depots - origin_index - 1

def get_bags_per_trip(remaining_depots, max_bags):
    bags_per_trip = remaining_depots // max_bags
    remaining_bags = remaining_depots % max_bags
    return bags_per_trip, remaining_bags

def get_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags):
    current_position = sorted_positions[origin_index + remaining_bags]
    for i in range(bags_per_trip):
        current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]
    return current_position

def get_trips_to_origin(origin_index, max_bags):
    trips_to_origin = origin_index // max_bags
    remaining_depots_origin = origin_index % max_bags
    return trips_to_origin, remaining_depots_origin

def get_distance_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags):
    current_position = 0
    for i in range(trips_to_origin):
        current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])
    current_position += abs(sorted_positions[origin_index - remaining_depots_origin])
    return current_position

def get_adjustment(sorted_positions):
    return max(-sorted_positions[0], abs(sorted_positions[len(sorted_positions) - 1]))