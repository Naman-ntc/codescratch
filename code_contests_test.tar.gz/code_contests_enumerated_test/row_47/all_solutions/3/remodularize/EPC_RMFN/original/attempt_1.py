def calculate_distance(num_depots, max_bags, depot_positions):
    sorted_positions = sort_positions(depot_positions)
    origin_index = find_origin_index(sorted_positions)
    total_distance = len(sorted_positions)
    remaining_depots = total_distance - origin_index - 1
    bags_per_trip, remaining_bags = calculate_bags_per_trip(remaining_depots, max_bags)
    current_position = calculate_current_position(sorted_positions, origin_index, remaining_bags, max_bags, bags_per_trip)
    trips_to_origin, remaining_depots_origin = calculate_trips_to_origin(origin_index, max_bags)
    current_position += calculate_trip_to_origin(sorted_positions, origin_index, remaining_depots_origin, max_bags, trips_to_origin)
    current_position *= 2
    return current_position - calculate_origin_distance(sorted_positions)

def sort_positions(depot_positions):
    sorted_positions = []
    for position in depot_positions:
        if position != 0:
            sorted_positions.append(position)
    sorted_positions.append(0)
    sorted_positions.sort()
    return sorted_positions

def find_origin_index(sorted_positions):
    return sorted_positions.index(0)

def calculate_bags_per_trip(remaining_depots, max_bags):
    bags_per_trip = remaining_depots // max_bags
    remaining_bags = remaining_depots % max_bags
    return bags_per_trip, remaining_bags

def calculate_current_position(sorted_positions, origin_index, remaining_bags, max_bags, bags_per_trip):
    current_position = sorted_positions[origin_index + remaining_bags]
    for i in range(bags_per_trip):
        current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]
    return current_position

def calculate_trips_to_origin(origin_index, max_bags):
    trips_to_origin = origin_index // max_bags
    remaining_depots_origin = origin_index % max_bags
    return trips_to_origin, remaining_depots_origin

def calculate_trip_to_origin(sorted_positions, origin_index, remaining_depots_origin, max_bags, trips_to_origin):
    current_position = 0
    for i in range(trips_to_origin):
        current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])
    return current_position

def calculate_origin_distance(sorted_positions):
    return max(-sorted_positions[0], abs(sorted_positions[-1]))

def main():
    test_cases = int(input())
    for _ in range(test_cases):
        num_depots, max_bags = map(int, input().split())
        depot_positions = [int(i) for i in input().split()]
        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)

if __name__ == '__main__':
    main()