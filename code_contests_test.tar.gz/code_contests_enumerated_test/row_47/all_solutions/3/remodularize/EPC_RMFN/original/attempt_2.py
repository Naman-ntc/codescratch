def calculate_distance(num_depots, max_bags, depot_positions):
    sorted_positions = sort_positions(depot_positions)
    origin_index = find_origin_index(sorted_positions)
    total_distance = len(sorted_positions)
    remaining_depots = total_distance - origin_index - 1
    remaining_bags = remaining_depots % max_bags
    current_position = get_current_position(sorted_positions, origin_index, remaining_bags, max_bags)

    trips_to_origin = origin_index // max_bags
    remaining_depots_origin = origin_index % max_bags
    current_position += get_trip_to_origin(sorted_positions, origin_index, remaining_depots_origin, max_bags)

    current_position *= 2

    return current_position - get_origin_correction(sorted_positions)

def sort_positions(depot_positions):
    sorted_positions = []
    for i in range(len(depot_positions)):
        if depot_positions[i] != 0:
            sorted_positions.append(depot_positions[i])
    sorted_positions.append(0)
    sorted_positions.sort()
    return sorted_positions

def find_origin_index(sorted_positions):
    return sorted_positions.index(0)

def get_current_position(sorted_positions, origin_index, remaining_bags, max_bags):
    current_position = sorted_positions[origin_index + remaining_bags]
    bags_per_trip = (len(sorted_positions) - origin_index - 1) // max_bags
    for i in range(bags_per_trip):
        current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]
    return current_position

def get_trip_to_origin(sorted_positions, origin_index, remaining_depots_origin, max_bags):
    current_position = 0
    trips_to_origin = origin_index // max_bags
    for i in range(trips_to_origin):
        current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])
    return current_position

def get_origin_correction(sorted_positions):
    return max(-sorted_positions[0], abs(sorted_positions[len(sorted_positions) - 1]))
    
def main():
    test_cases = int(input())
    for _ in range(test_cases):
        num_depots, max_bags = map(int, input().split())
        depot_positions = [int(i) for i in input().split()]
        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)

if __name__ == '__main__':
    main()