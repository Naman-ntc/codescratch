def calculate_distance(num_depots, max_bags, depot_positions):
    sorted_positions = sort_positions(depot_positions)
    origin_index = get_origin_index(sorted_positions)
    remaining_depots = get_remaining_depots(origin_index, num_depots)
    bags_per_trip, remaining_bags = get_bags_per_trip(remaining_depots, max_bags)
    current_position = get_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags)
    trips_to_origin, remaining_depots_origin = get_trips_to_origin(origin_index, max_bags)
    current_position += get_distance_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags)
    current_position *= 2
    return current_position - get_adjustment(sorted_positions)

def sort_positions(depot_positions):
    sorted_positions = []
    for position in depot_positions:
        if position != 0:
            sorted_positions.append(position)
    sorted_positions.append(0)
    sorted_positions.sort()
    return sorted_positions

def get_origin_index(sorted_positions):
    return sorted_positions.index(0)

def get_remaining_depots(origin_index, num_depots):
    total_distance = len(sorted_positions)
    return total_distance - origin_index - 1

def get_bags_per_trip(remaining_depots, max_bags):
    bags_per_trip = remaining_depots // max_bags
    remaining_bags = remaining_depots % max_bags
    return bags_per_trip, remaining_bags

def get_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags):
    current_position = sorted_positions[origin_index + remaining_bags]
    for i in range(bags_per_trip):
        current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]
    return current_position

def get_trips_to_origin(origin_index, max_bags):
    trips_to_origin = origin_index // max_bags
    remaining_depots_origin = origin_index % max_bags
    return trips_to_origin, remaining_depots_origin

def get_distance_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags):
    current_position = 0
    for i in range(trips_to_origin):
        current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])
    return current_position

def get_adjustment(sorted_positions):
    return max(-sorted_positions[0], abs(sorted_positions[total_distance - 1]))

def main():
    test_cases = int(input())
    for _ in range(test_cases):
        num_depots, max_bags = map(int, input().split())
        depot_positions = [int(i) for i in input().split()]
        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)

if __name__ == '__main__':
    main()