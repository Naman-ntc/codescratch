def calculate_distance(num_depots, max_bags, depot_positions):
    sorted_positions = sort_positions(depot_positions)
    origin_index = find_origin_index(sorted_positions)
    remaining_depots = calculate_remaining_depots(origin_index, num_depots)
    bags_per_trip, remaining_bags = calculate_bags_per_trip(remaining_depots, max_bags)
    current_position = calculate_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags)
    trips_to_origin, remaining_depots_origin = calculate_trips_to_origin(origin_index, max_bags)
    current_position += calculate_current_position_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags)
    total_distance = calculate_total_distance(current_position, sorted_positions)
    return total_distance

def sort_positions(depot_positions):
    sorted_positions = []
    for i in range(len(depot_positions)):
        if depot_positions[i] != 0:
            sorted_positions.append(depot_positions[i])
    sorted_positions.append(0)
    sorted_positions.sort()
    return sorted_positions

def find_origin_index(sorted_positions):
    origin_index = sorted_positions.index(0)
    return origin_index

def calculate_remaining_depots(origin_index, num_depots):
    total_distance = len(origin_index)
    remaining_depots = total_distance - origin_index - 1
    return remaining_depots

def calculate_bags_per_trip(remaining_depots, max_bags):
    bags_per_trip = remaining_depots // max_bags
    remaining_bags = remaining_depots % max_bags
    return bags_per_trip, remaining_bags

def calculate_current_position(sorted_positions, origin_index, remaining_bags, bags_per_trip, max_bags):
    current_position = sorted_positions[origin_index + remaining_bags]
    for i in range(bags_per_trip):
        current_position += sorted_positions[origin_index + remaining_bags + max_bags * (i + 1)]
    return current_position

def calculate_trips_to_origin(origin_index, max_bags):
    trips_to_origin = origin_index // max_bags
    remaining_depots_origin = origin_index % max_bags
    return trips_to_origin, remaining_depots_origin

def calculate_current_position_to_origin(sorted_positions, origin_index, remaining_depots_origin, trips_to_origin, max_bags):
    current_position = abs(sorted_positions[origin_index - remaining_depots_origin])
    for i in range(trips_to_origin):
        current_position += abs(sorted_positions[origin_index - (remaining_depots_origin + max_bags * (i + 1))])
    return current_position

def calculate_total_distance(current_position, sorted_positions):
    current_position *= 2
    total_distance = current_position - max(-sorted_positions[0], abs(sorted_positions[total_distance - 1]))
    return total_distance

def main():
    test_cases = int(input())
    for _ in range(test_cases):
        num_depots, max_bags = map(int, input().split())
        depot_positions = [int(i) for i in input().split()]
        distance = calculate_distance(num_depots, max_bags, depot_positions)
        print(distance)

if __name__ == '__main__':
    main()