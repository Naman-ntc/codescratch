for _ in range(int(input())):
    n,k=map(int,input().split())
    a=list(map(int,input().split()))
    a.sort()
    ans=0
    i=0
    while i<n:
        if a[i]<0:
            ans+=2*abs(a[i])
        i+=k
    i=n-1
    while i>=0:
        if a[i]>0:
            ans+=2*a[i]
        i-=k
    maxx=max(abs(a[0]),abs(a[n-1]))
    print(ans-maxx)
