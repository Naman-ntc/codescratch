def solveee(a,left):
    inn=sorted(a)
    ans=0
    fgh=1
    while(len(inn)):
        t=inn[-1]
        i=1
        while(i<=k and len(inn)):
            del inn[-1]
            i+=1
        if(fgh ==1 and not(left)):
            ans+=t
        else:
            ans+=t*2
        fgh+=1
    return ans
def func(a,b):
    return solveee(a,True)+solveee(b,False)
t=int(input())
while(t):
    t=t-1
    n,k=map(int,input().split())
    pos,neg=[],[]
    cc=list(map(int,input().split()))
    for i in range(n):
        if(cc[i]>=0):
            pos.append(cc[i])
        else:
            neg.append(abs(cc[i]))
    t1=func(pos,neg)
    t2=func(neg,pos)
    print(min(t1,t2))