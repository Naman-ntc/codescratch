def fun(n,arr,k):
    cost=0
    i=0
    if not(arr):
        return 0
    arr=arr[::-1]
    if k==1:
        return 2*sum(arr)
    while(i<n):
        cost+=arr[i]+arr[min(i+k-1,n-1)]
        for i in range(i,min(n,i+k)-1):
            cost+=abs(arr[i]-arr[i+1])
        i+=2
    return cost
def fun2(a1,a2):
    x=0
    y=0
    if a1:
        x=max(a1)
    if a2:
        y=max(a2)
    return max(x,y)
for _ in range(int(input())):
    n,k=map(int,input().split())
    arr=list(map(int,input().split()))
    a1=[]
    a2=[]
    al=0
    bl=0
    for i in range(n):
        if arr[i]<=0:
            a1.append(abs(arr[i]))
            al+=1
        else:
            a2.append(arr[i])
            bl+=1
    a1.sort()
    a2.sort()
    print(fun(al,a1,k)+fun(bl,a2,k)-fun2(a1,a2))