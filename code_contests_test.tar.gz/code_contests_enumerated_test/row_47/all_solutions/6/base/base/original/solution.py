for ii in range(int(input())):
	n, q = map(int, input().split())
	a = list(map(int, input().split()))
	x,y=[],[]
	for jj in range(n):
		if a[jj]>=0:
			x.append(a[jj])
		else:
			y.append(abs(a[jj]))
	x,y=sorted(x),sorted(y)
	if not x:
		ans=y[-1]
		for jj in range(len(y)-1-q,-1,-q):
			ans+=2*abs(y[jj])
		print(ans)
	elif not y:
		ans=x[-1]
		for jj in range(len(x)-1-q,-1,-q):
			ans+=2*abs(x[jj])
		print(ans)
	elif x[-1]>y[-1]:
		ans=x[-1]
		for jj in range(len(x)-q-1,-1,-q):
			ans+=2*abs(x[jj])
		for kk in range(len(y)-1,-1,-q):
			ans+=2*abs(y[kk])
		print(ans)
	else:
		ans=y[-1]
		for jj in range(len(x)-1,-1,-q):
			ans+=2*abs(x[jj])
		for kk in range(len(y)-q-1,-1,-q):
			ans+=2*abs(y[kk])
		print(ans)