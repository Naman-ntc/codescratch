
def fun(arr,k):
    n=len(arr)
    x=0
    for i in range(n-1,-1,-1*k):
        x+=(2*arr[i])

    return x

for _ in range(int(input())):
    n,k=map(int,input().split())
    a=[int(x) for x in input().split()]

    ans=0
    a1=[]
    a2=[]
    
    for i in range(n):
        if a[i]>0:
            a1.append(a[i])
        
        elif a[i]<0:
            a2.append(-1*a[i])

    a1.sort()
    a2.sort()

    mx=0

    if a1:
        mx=max(mx,a1[-1])
    if a2:
        mx=max(mx,a2[-1])
    
    
    print(fun(a1,k)+fun(a2,k)-mx)
