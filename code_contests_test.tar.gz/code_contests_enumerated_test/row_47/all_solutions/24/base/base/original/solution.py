for _ in range(int(input())):
  n, k = map(int, input().split())
  a = list(map(int, input().split()))
  a.sort()

  pa = list(filter(lambda x: x > 0, reversed(a)))
  na = list(map(lambda x: -x, filter(lambda x: x < 0, a)))

  c = 0
  for i in range(0, len(pa), k):
    # print(pa[i], end=' ')
    c += pa[i] * 2
  if len(pa) and i + k != len(pa) and False:
    # print(pa[-1], end=' ')
    c += pa[-1] * 2
  # print()

  for i in range(0, len(na), k):
    # print(na[i], end=' ')
    c += na[i] * 2
  if len(na) and i + k != len(na) and False:
    # print(na[-1], end=' ')
    c += na[-1] * 2
  # print()

  c -= max(pa[0] if len(pa) else 0, na[0] if len(na) else 0)
  print(c)
