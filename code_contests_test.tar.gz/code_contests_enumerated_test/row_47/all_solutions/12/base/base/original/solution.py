import sys

# sys.setrecursionlimit(200005)
int1 = lambda x: int(x)-1
pDB = lambda *x: print(*x, end="\n", file=sys.stderr)
p2D = lambda x: print(*x, sep="\n", end="\n\n", file=sys.stderr)
def II(): return int(sys.stdin.readline())
def LI(): return list(map(int, sys.stdin.readline().split()))
def LLI(rows_number): return [LI() for _ in range(rows_number)]
def LI1(): return list(map(int1, sys.stdin.readline().split()))
def LLI1(rows_number): return [LI1() for _ in range(rows_number)]
def SI(): return sys.stdin.readline().rstrip()
# dij = [(0, 1), (-1, 0), (0, -1), (1, 0)]
# dij = [(0, 1), (-1, 0), (0, -1), (1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]
# inf = 18446744073709551615
inf = 4294967295
# md = 10**9+7
md = 998244353

def cal(aa, k):
    if not aa: return 0
    n = len(aa)
    ans = 0
    for i in range(n-1, -1, -k):
        ans += aa[i]*2
    return ans

def solve():
    n, k = LI()
    aa = LI()
    ll, rr = [], []
    for a in aa:
        if a > 0: rr.append(a)
        else: ll.append(-a)
    ll.sort()
    rr.sort()
    mx = 0
    if ll: mx = max(mx, ll[-1])
    if rr: mx = max(mx, rr[-1])
    ans = cal(ll, k)+cal(rr, k)-mx
    print(ans)

for testcase in range(II()):
    solve()
