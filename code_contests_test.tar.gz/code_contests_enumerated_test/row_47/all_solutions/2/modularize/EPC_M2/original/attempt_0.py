import sys
import math

def read_integer():
    return int(sys.stdin.readline())

def read_list():
    return list(map(int, sys.stdin.readline().split()))

def read_map():
    return map(int, sys.stdin.readline().split())

def least_common_multiple(a, b):
    return abs(a * b) // math.gcd(a, b)

def calculate_min_distance(n, k, depots):
    positive_depots = []
    negative_depots = []
    for i in depots:
        if i > 0:
            positive_depots.append(i)
        elif i < 0:
            negative_depots.append(-i)
    positive_depots.sort(reverse=True)
    negative_depots.sort(reverse=True)
    max_distance = 0
    if positive_depots:
        max_distance = max(positive_depots)
    if negative_depots:
        max_distance = max(max_distance, max(negative_depots))
    min_distance = -max_distance
    if positive_depots:
        for i in range(0, len(positive_depots), k):
            min_distance += 2 * positive_depots[i]
    if negative_depots:
        for i in range(0, len(negative_depots), k):
            min_distance += 2 * negative_depots[i]
    return min_distance

def main():
    for _ in range(read_integer()):
        n, k = read_map()
        depots = read_list()
        min_distance = calculate_min_distance(n, k, depots)
        print(min_distance)

if __name__ == '__main__':
    main()