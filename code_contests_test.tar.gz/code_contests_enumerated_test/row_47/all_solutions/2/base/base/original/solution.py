import sys
from collections import deque
import math
from bisect import bisect_left
from functools import cmp_to_key
def II():
	return int(sys.stdin.readline())
 
def LI():
	return list(map(int, sys.stdin.readline().split()))
 
def MI():
	return map(int, sys.stdin.readline().split())
 
def SI():
	return sys.stdin.readline().strip()
 
def FACT(n, mod):
    s = 1
    facts = [1]
    for i in range(1,n+1):
        s*=i
        s%=mod
        facts.append(s)
    return facts[n]
 
def C(n, k, mod):
    return (FACT(n,mod) * pow((FACT(k,mod)*FACT(n-k,mod))%mod,mod-2, mod))%mod
 
def lcm(a,b):
    return abs(a*b) // math.gcd(a, b)

for _ in range(II()):
    n,k = MI()
    a = LI()
    x = []
    y = []
    for i in a:
        if i>0:
            x.append(i)
        elif i < 0:
            y.append(-i)
    x.sort(reverse=True)
    y.sort(reverse=True)
    m = 0
    if x:
        m = max(x)
    if y:
        m = max(m,max(y))
    ans = -m
    if x:
        for i in range(0, len(x), k):
            ans+=2*x[i]
    if y:
        for i in range(0, len(y), k):
            ans+=2*y[i]
    print(ans)

    
