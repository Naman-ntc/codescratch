import sys
from collections import deque
import math
from bisect import bisect_left
from functools import cmp_to_key

def read_integer():
    return int(sys.stdin.readline())

def read_list():
    return list(map(int, sys.stdin.readline().split()))

def read_map():
    return map(int, sys.stdin.readline().split())

def read_string():
    return sys.stdin.readline().strip()

def factorial(n, mod):
    s = 1
    facts = [1]
    for i in range(1, n+1):
        s *= i
        s %= mod
        facts.append(s)
    return facts[n]

def combination(n, k, mod):
    return (factorial(n, mod) * pow((factorial(k, mod) * factorial(n-k, mod)) % mod, mod-2, mod)) % mod

def least_common_multiple(a, b):
    return abs(a * b) // math.gcd(a, b)

for _ in range(read_integer()):
    n, k = read_map()
    depots = read_list()
    positive_depots = []
    negative_depots = []
    for i in depots:
        if i > 0:
            positive_depots.append(i)
        elif i < 0:
            negative_depots.append(-i)
    positive_depots.sort(reverse=True)
    negative_depots.sort(reverse=True)
    max_distance = 0
    if positive_depots:
        max_distance = max(positive_depots)
    if negative_depots:
        max_distance = max(max_distance, max(negative_depots))
    min_distance = -max_distance
    if positive_depots:
        for i in range(0, len(positive_depots), k):
            min_distance += 2 * positive_depots[i]
    if negative_depots:
        for i in range(0, len(negative_depots), k):
            min_distance += 2 * negative_depots[i]
    print(min_distance)