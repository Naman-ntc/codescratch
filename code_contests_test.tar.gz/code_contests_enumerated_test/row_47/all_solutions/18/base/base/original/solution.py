from sys import stdin,stdout,setrecursionlimit
from math import gcd,sqrt,factorial,pi,inf
from collections import deque,defaultdict
from bisect import bisect,bisect_left
from time import time
from itertools import permutations as per
from heapq import heapify,heappush,heappop,heappushpop
input=stdin.readline
R=lambda:map(int,input().split())
I=lambda:int(input())
S=lambda:input().rstrip('\r\n')
L=lambda:list(R())
P=lambda x:stdout.write(str(x)+'\n')
lcm=lambda x,y:(x*y)//gcd(x,y)
nCr=lambda x,y:(f[x]*inv((f[y]*f[x-y])%N))%N
inv=lambda x:pow(x,N-2,N)
sumx=lambda x:(x**2+x)//2
N=10**9+7

def get(a):
    ans=0
    a=a[::-1]
    for i in range(0,len(a),k):
        ans+=a[i]
    return ans*2

for _ in range(I()):
    n,k=R()
    a=L()
    x=sorted([abs(i) for i in a if i<0])
    y=sorted([i for i in a if i>=0])
    #print(y)
    ans=0
    if x and y:
        if x[-1]>y[-1]:
            ans-=x[-1]
        else:
            ans-=y[-1]
        ans += get(x)
        ans += get(y)
    elif x:
        ans-=x[-1]
        ans+=get(x)
    else:
        ans-=y[-1]
        ans+=get(y)
    print(ans)

