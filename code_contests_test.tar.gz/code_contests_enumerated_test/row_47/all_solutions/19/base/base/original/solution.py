#import sys
#sys.stdin=open('input.txt','r')
#sys.stdout=open('output.txt','w')


def solve():
    n,k=map(int,input().split())
    l=list(map(int,input().split()))
    r=[]
    q=[]
    for i in l:
        
        if(i>=0):
            #print(i
            q.append(i)
        else:
            r.append(i)
    ans=[]
    q.sort()
    r.sort(reverse=True)
    #print(r)
    m=len(q)
    x=len(r)
    if(m>0):
        val=m-1
        ans.append(q[val])
        val-=k
        while(val>=0):
            ans.append(q[val])
            val-=k
    #print(ans)
    if(x>0):
        val=x-1
        ans.append(-r[val])
        val-=k
        while(val>=0):
            ans.append(-r[val])
            val-=k
    answer=0
    #print(ans)
    ans.sort()
    for i in range(len(ans)-1):
        answer+=ans[i]*2
    answer+=ans[len(ans)-1]
    print(answer)




t=int(input())
while(t!=0):
    solve()
    t-=1
