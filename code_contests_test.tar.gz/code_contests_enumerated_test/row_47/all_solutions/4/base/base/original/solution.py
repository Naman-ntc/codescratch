cases = int(input())
for i in range(cases):
    n, k = map(int, input().split())
    arr = list(map(int, input().split()))
    pos = list(filter(lambda x: x>=0, arr))
    pos.sort()
    neg = list(map(abs ,filter(lambda x: x<0, arr)))
    neg.sort()
    if neg and pos:
        if max(pos)>max(neg):
            count = 0
            n = len(neg)
            p = n-1
            while p>=0:
                count += (2*neg[p])
                p -= k
            n = len(pos)
            p = n-1
            while p>=0:
                if p == (n-1):
                    count += pos[n-1]
                else:
                    count += (2*pos[p])
                p -= k
        else:
            count = 0
            n = len(pos)
            p = n-1
            while p>=0:
                count += (2*pos[p])
                p -= k
            n = len(neg)
            p = n-1
            while p>=0:
                if p == (n-1):
                    count += neg[n-1]
                else:
                    count += (2*neg[p])
                p -= k
    elif pos:
        count = 0
        p = n-1
        while p>=0:
            if p == (n-1):
                count += pos[n-1]
            else:
                count += (2*pos[p])
            p -= k 
    else:
        count = 0
        p = n-1
        while p>=0:
            if p == (n-1):
                count += neg[n-1]
            else:
                count += (2*neg[p])
            p -= k
    print(count)

