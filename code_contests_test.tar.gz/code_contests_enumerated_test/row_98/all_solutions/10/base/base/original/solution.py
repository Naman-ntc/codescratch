t = int(input())
for i in range(t):
    s = input()
    l1 = list(s)
    s1 = input()
    l2 = list(s1)
    l3 = []
    sum = 0
    k = 0
    for i in range(0,len(l2)):
        for j in range(0,len(l1)):
            if(l2[i] == l1[j]):
               l3.append(j+1)
                
    l = len(l3)
    for i in range(0,l-1):
        sum = sum + (abs(l3[i+1] - l3[i]))
    print(sum)
