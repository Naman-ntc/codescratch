for _ in range(int(input())):
	x=0
	mp={}
	for i in input():
		mp[i]=x
		x+=1
	
	s=[mp[i] for i in input()]
	print(sum(abs(s[i]-s[i+1]) for i in range(len(s)-1)))
	