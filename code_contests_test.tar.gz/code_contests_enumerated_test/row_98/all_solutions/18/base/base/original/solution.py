def input_int():
    return int(input())

def input_list():
    return input().split(' ')

def input_list_int():
    return list(map(int, input_list()))
    
test_cases = input_int()
keyboards = []
keywords = []

while test_cases:
    keyboards.append(input())
    keywords.append(input())
    
    test_cases -= 1

for i in range(len(keywords)):
    dict_key = {}
    result = 0
    
    for letter in keywords[i]:
        if letter not in dict_key:
            dict_key[letter] = 0
            
    for index, letter in enumerate(keyboards[i]):
        if letter in dict_key:
            dict_key[letter] = index+1
    
    prev = -1
    
    for letter in keywords[i]:
        if prev == -1:
            prev = dict_key[letter]
            continue
        
        result += abs(prev - dict_key[letter])
        prev = dict_key[letter]

    print(result)