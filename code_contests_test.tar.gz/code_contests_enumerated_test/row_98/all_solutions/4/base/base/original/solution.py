t = int(input())
for j in range(t):
    letters = str(input())
    s = str(input())
    dictiony = {}
    calculating = []
    word = []
    sum = 0
    for m in s:
        word.append(m)
    for i in letters:
        dictiony[i] = letters.index(i)
    for k in word:
        calculating.append(dictiony.get(k))
    n = 0
    while n != (len(word)-1) and len(s) > 0:
        calc = abs(calculating[n + 1] - calculating[n])
        sum += calc
        n += 1
    print(sum)

