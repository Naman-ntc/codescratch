t = int(input())
for i in range(t):
    al = input()
    m = {}
    for j in range(26):
        m[al[j]] = j
    s = input()
    ans = 0
    for j in range(1, len(s)):
        ans += abs(m[s[j]] - m[s[j - 1]])
    print(ans)
