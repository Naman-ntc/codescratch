def calc(i, s):

    ans = 0
    for val in s:
        ans += abs(i - index[val])
        i = index[val]

    return ans


for _ in range(int(input())):
    keyboard = input()
    string = input()

    index = {}
    for i in range(len(keyboard)):
        index.update({keyboard[i]: i})

    a = 10**9
    for i in range(len(keyboard)):
        cur_idx = index[keyboard[i]]
        a = min(a, calc(cur_idx, string))

    print(a)
