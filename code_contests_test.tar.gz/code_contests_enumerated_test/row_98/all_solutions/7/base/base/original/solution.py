import sys
input = lambda: sys.stdin.readline().rstrip()
sys.setrecursionlimit(10**5)
INF = 10**18

def solve():
    keyboard = input()
    s = input()

    cur = -1
    ans = 0
    for c in s:
        if cur == -1:
            cur = keyboard.index(c)
        else:
            cur2 = keyboard.index(c)
            ans += abs(cur2 - cur)
            cur = cur2
    print(ans)
    
Q = int(input())
for _ in range(Q):
    solve()