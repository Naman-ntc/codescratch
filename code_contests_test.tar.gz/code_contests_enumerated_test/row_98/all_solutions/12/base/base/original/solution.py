def solve():
	atoz = list(input())
	s = input()
	n = [atoz.index(i)+1 for i in s]
	c = 0
	for i in range(len(n)-1):
		c = c + abs(n[i] - n[i+1])
	print(c)
t = int(input())
for _ in range(t):
	solve()