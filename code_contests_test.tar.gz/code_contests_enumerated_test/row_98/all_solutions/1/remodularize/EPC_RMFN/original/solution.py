def calculate_time(key_order, word):
    key_positions = {}
    for i in range(len(key_order)):
        key_positions[key_order[i]] = i + 1
    time = 0
    for i in range(1, len(word)):
        time += abs(key_positions[word[i]] - key_positions[word[i-1]])
    return time

def main():
    t = int(input())
    results = []
    for _ in range(t):
        key_order = input()
        word = input()
        time = calculate_time(key_order, word)
        results.append(time)
    for result in results:
        print(result)

if __name__ == '__main__':
    main()