

t = int(input())

res = []

for i in range(t):
    d = {}
    s2 = str(input())
    for i in range(len(s2)):
        d[s2[i]] = i + 1
    s = str(input())
    ans = 0
    for i in range(1, len(s)):
        ans += abs(d[s[i]] - d[s[i-1]])
    res.append(ans)

for i in res:
    print(i)