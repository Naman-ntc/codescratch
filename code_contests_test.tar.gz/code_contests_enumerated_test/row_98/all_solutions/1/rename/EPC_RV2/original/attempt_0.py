t = int(input())

results = []

for _ in range(t):
    key_order = str(input())
    key_positions = {}
    for i in range(len(key_order)):
        key_positions[key_order[i]] = i + 1
    word = str(input())
    time = 0
    for i in range(1, len(word)):
        time += abs(key_positions[word[i]] - key_positions[word[i-1]])
    results.append(time)

for result in results:
    print(result)