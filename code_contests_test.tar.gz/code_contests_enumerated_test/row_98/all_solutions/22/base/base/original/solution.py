import math

def solve(s, d):
    r = 0
    if len(s) <= 1:
        return r
    for i in range(1, len(s)):
        r += abs(d[s[i]] - d[s[i - 1]])
    
    return r

t=int(input())
for _ in range(t):
    s = input()
    d = {}
    for i in range(len(s)):
        d[s[i]] = i + 1
    s = input()
    print(solve(s, d))