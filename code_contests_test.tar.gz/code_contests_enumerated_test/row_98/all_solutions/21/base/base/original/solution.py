t=int(input())
for i in range(t):
	sx=input()
	d={}
	for i in range(len(sx)):
		d[sx[i]]=i+1
	# print(d)
	s=input()
	c=0
	curr=d[s[0]]
	for i in range(1,len(s)):
		# print(curr,d[s[i]],abs(curr-d[s[i]]))
		c+=abs(curr-d[s[i]])
		curr=d[s[i]]
	print(c)