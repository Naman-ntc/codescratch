t=int(input())
for i in range(t):
    alph=input()
    s=input()
    suu=0
    for i in range(len(s)-1):
        suu+=abs(alph.index(s[i+1])-alph.index(s[i]))
    print(suu)