t = int(input())

for _ in range(t):
    keyboard = input()
    word = input()
    total_time = 0
    
    for i in range(len(word) - 1):
        total_time += abs(keyboard.index(word[i+1]) - keyboard.index(word[i]))
    
    print(total_time)