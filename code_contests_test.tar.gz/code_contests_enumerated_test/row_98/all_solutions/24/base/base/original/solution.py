#  map(int, input().split())
#  list(map(int, input().split()))

for _ in range(int(input())):
    keyboard = list(input())
    s = list(input())
    time = 0
    for i in range(1,len(s)):
        time += abs(keyboard.index(s[i]) - keyboard.index(s[i - 1]))
    print(time)