for i in range(int(input())):
    key = input()
    s = input()
    cnt=0
    for j in range(len(s)-1):
        cnt+=abs(key.index(s[j]) - key.index(s[j+1]))
    print(cnt)
