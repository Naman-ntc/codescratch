from itertools import permutations, combinations, combinations_with_replacement
from bisect import bisect_left, bisect_right  # https: // docs.python.org/3/library/bisect.html
from typing import List
from math import ceil, floor, gcd, sqrt
from itertools import accumulate
import string

def main():
    tt = int(input())
    for _ in range(tt):
        # n, a, b = map(int, input().split())
        # lst1 = list(map(int, input().split()))
        # lst2 = list(map(int, input().split()))
        n = input()
        dd = {}
        for i in range(26):
            dd[n[i]] = dd.get(n[i], i+1)
        # print(dd)
        word = input()

        s = 0
        for j in range(1, len(word)):
            s= s+ abs(dd[word[j]]-dd[word[j-1]])
        print(s)
main()