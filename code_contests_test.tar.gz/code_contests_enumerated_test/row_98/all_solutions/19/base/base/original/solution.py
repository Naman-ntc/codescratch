def main():
    n = int(input())
    for i in range(n):
        alp = input()
        word = input()
        pr = alp.index(word[0])
        sum = 0
        for j in range(1, len(word)):
            x = alp.index(word[j])
            sum += abs(pr - x)
            pr = x

        print(sum)

main()