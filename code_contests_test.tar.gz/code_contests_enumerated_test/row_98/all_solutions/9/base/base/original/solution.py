t = int(input())

for _ in range(t):
    order = dict(zip(list(input()),range(1,27)))
    string = input()
    time=0
    for i in range(1,len(string)):
        time+= abs(order[string[i]]-order[string[i-1]])
    print(time)