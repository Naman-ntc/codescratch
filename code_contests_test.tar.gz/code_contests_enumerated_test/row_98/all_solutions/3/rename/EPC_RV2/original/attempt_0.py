test_cases = int(input())
for _ in range(test_cases):
    keyboard = list(input())
    word = list(input())
    total_time = 0
    previous_index = keyboard.index(word[0])
    for letter in word[1:]:
        current_index = keyboard.index(letter)
        total_time += abs(current_index - previous_index)
        previous_index = current_index
    print(total_time)