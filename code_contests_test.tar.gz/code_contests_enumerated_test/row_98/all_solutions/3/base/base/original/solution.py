t = int(input())
for qwer in range(t):
    clav = list(input())
    sl = list(input())
    s = 0
    d = clav.index(sl[0])
    for el in sl[1:]:
        s += abs(clav.index(el) - d)
        d = clav.index(el)
    print(s)