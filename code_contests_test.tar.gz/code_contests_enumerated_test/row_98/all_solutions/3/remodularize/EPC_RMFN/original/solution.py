def calculate_typing_time(keyboard, word):
    total_time = 0
    previous_index = keyboard.index(word[0])
    for letter in word[1:]:
        current_index = keyboard.index(letter)
        total_time += abs(current_index - previous_index)
        previous_index = current_index
    return total_time


def main():
    test_cases = int(input())
    for _ in range(test_cases):
        keyboard = list(input())
        word = list(input())
        typing_time = calculate_typing_time(keyboard, word)
        print(typing_time)


if __name__ == '__main__':
    main()