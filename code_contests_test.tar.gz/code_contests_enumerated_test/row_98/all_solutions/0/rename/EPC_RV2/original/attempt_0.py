import sys
input = sys.stdin.readline

t = int(input())
results = []

for _ in range(t):
    raw_keyboard = input()[:-1]
    word = input()[:-1]
    time = 0

    if len(word) == 1:
        results.append(str(0))
        continue

    key_map = {}
    for i, key in enumerate(raw_keyboard):
        key_map[key] = i + 1

    for i in range(len(word)-1):
        time += abs(key_map[word[i]] - key_map[word[i+1]])
    results.append(str(time))

print('\n'.join(results))