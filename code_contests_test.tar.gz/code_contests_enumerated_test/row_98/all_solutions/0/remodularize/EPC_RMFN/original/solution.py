import sys

def calculate_typing_time(keyboard, word):
    time = 0

    if len(word) == 1:
        return 0

    key_map = {}
    for i, key in enumerate(keyboard):
        key_map[key] = i + 1

    for i in range(len(word)-1):
        time += abs(key_map[word[i]] - key_map[word[i+1]])

    return time

def main():
    t = int(input())
    results = []

    for _ in range(t):
        raw_keyboard = input().strip()
        word = input().strip()

        time = calculate_typing_time(raw_keyboard, word)
        results.append(str(time))

    print('\n'.join(results))

if __name__ == '__main__':
    main()