
t = int(input())


while t > 0:
    keyboard = input()
    s = input()
    start = -1
    total = 0
    for i in range(len(s)):
        loc = keyboard.find(s[i])
        # print(s[i], loc)
        assert loc != -1
        if start >= 0:
            total += abs(loc - start)
        start = loc
    print(total)
    t -= 1