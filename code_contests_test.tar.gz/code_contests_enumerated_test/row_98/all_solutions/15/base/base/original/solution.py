for _ in range(int(input())):
    a = input()
    b = input()
    c = {}
    s = 0
    for i in a:
        c[i] = a.index(i)
    for i in range(len(b) - 1):
        s = s + abs(c[b[i + 1]] - c[b[i]])
    print(s)
