ladwa = int(input())
for fcuk in range(ladwa):
	klh = []
	sum=0
	shakeer = input()
	basha = input()
	for j in range(len(basha)):
		for i in range(len(shakeer)):
			if(basha[j]==shakeer[i]):
				klh.append(i+1)
	for i in range(1,len(klh)):
		sum = sum + abs(klh[i-1] - klh[i])
	print(sum)