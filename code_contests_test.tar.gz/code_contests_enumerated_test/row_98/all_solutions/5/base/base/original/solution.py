for i in range(int(input())):
    cnt = 0
    st = input()
    st1 = input()
    for j in range(1, len(st1)):
        cnt += abs(st.index(st1[j]) - st.index(st1[j - 1]))
    print(cnt)